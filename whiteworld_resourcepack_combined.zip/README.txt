Аметистовый набор (объединённый ресурспак).

Солнце: аметисто-скалковое с пульсацией.
  1.21.11+ (включая 26.x): assets/minecraft/textures/environment/celestial/sun.png
    — анимированная полоса 64x512 (8 кадров) + sun.png.mcmeta.
  До 1.21.11: статичная копия assets/minecraft/textures/environment/sun.png.

Паук: фиолетовый, без глаз (assets/minecraft/textures/entity/spider/).

Цвет неба ресурспаком не меняется (нужен датапак).

Кристальное солнце белого мира: assets/minecraft/textures/environment/celestial/moon/new_moon.png
  Это спрайт фазы луны new_moon; датапак whiteworld включает его только в белом измерении
  (visual/moon_phase = new_moon) и водит по небу как солнце.

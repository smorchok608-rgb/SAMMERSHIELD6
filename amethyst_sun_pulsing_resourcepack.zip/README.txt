Аметисто-скалковое солнце с пульсацией.
1.21.11+ (включая 26.x): assets/minecraft/textures/environment/celestial/sun.png
  — анимированная полоса 64x512 (8 кадров) + sun.png.mcmeta.
До 1.21.11: статичная копия assets/minecraft/textures/environment/sun.png.
Цвет неба ресурспаком не меняется (нужен датапак).
